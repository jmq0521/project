import Off from "@/components/resgier/off"
export default[
  {
    path: '/off',
    name: 'off',
    meta: {
      title: '企铛铛'
    },
    component: Off
  }
]

