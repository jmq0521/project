import JoinCar from "@/components/car/index"
export default[
  {
    path: '/joincar',
    name: 'joincar',
    meta: {
      title: '订单预选区'
    },
    component: JoinCar
  }
]

