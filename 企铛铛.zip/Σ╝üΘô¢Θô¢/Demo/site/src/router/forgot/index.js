import Forgot from "@/components/resgier/forgot"
export default[
  {
    path: '/forgot',
    name: 'forgot',
    meta: {
      title: '企铛铛'
    },
    component: Forgot
  }
]

