import Resgier from "@/components/resgier/index"
export default[
  {
    path: '/resgier',
    name: 'resgier',
    meta: {
      title: '企铛铛'
    },
    component: Resgier
  }
]

