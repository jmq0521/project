import Login from "@/components/login/index"
export default[
  {
    path: '/login',
    name: 'login',
    meta: {
      title: '企铛铛'
    },
    component: Login
  }
]

