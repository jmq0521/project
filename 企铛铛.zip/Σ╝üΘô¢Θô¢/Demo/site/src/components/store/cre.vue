<template>
  <div id="cre">
    <div class="top">
      <h4>商品创建</h4>
    </div>
  </div>
</template>

<script>
  export default {
    name: "cre"
  }
</script>

<style scoped>
  #cre{
    width: 1010px;
    height: 600px;
    margin-bottom: 20px;
    border-top: 5px solid #626262;
    margin-top: 10px;
  }
  .top{height: 50px;background: #ffffff;}
  .top h4{
    text-indent: 30px;
    font-size: 14px;
    line-height: 50px;
    float: left;
    color: #313131;
  }
</style>
